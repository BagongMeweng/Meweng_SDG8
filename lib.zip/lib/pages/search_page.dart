import 'dart:math' as math;
import 'dart:ui' show PointerDeviceKind;

import 'package:flutter/material.dart';

import '../components/job_card.dart';
import '../utils/app_theme.dart';
import '../utils/mock_data.dart';
import '../utils/models.dart';
import '../utils/responsive.dart';

/// Kategori filter gaji. Sebuah lowongan cocok jika rentang gajinya
/// (salaryMin..salaryMax) beririsan dengan rentang kategori [min, max).
enum _SalaryFilter {
  under3('Di bawah Rp3 jt', 0, 3000000),
  from3to4('Rp3–4 jt', 3000000, 4000000),
  from4to5('Rp4–5 jt', 4000000, 5000000),
  over5('Di atas Rp5 jt', 5000000, null);

  const _SalaryFilter(this.label, this.min, this.max);

  final String label;
  final int min;

  /// Batas atas (tidak termasuk). null berarti tanpa batas atas.
  final int? max;

  bool matches(Job job) {
    final upper = max;
    return job.salaryMax >= min && (upper == null || job.salaryMin < upper);
  }
}

/// Cari Lowongan (Fitur 4). Satu [CustomScrollView] berisi:
/// 1. search bar, 2. filter chip Gaji dan Lokasi, 3. teks jumlah hasil,
/// 4. daftar lowongan: List di ponsel, Grid 2-3 kolom di layar lebar.
///
/// Kata kunci dan kedua filter digabung (AND). Data dari mock data.
class SearchPage extends StatefulWidget {
  const SearchPage({super.key});

  @override
  State<SearchPage> createState() => _SearchPageState();
}

class _SearchPageState extends State<SearchPage> {
  /// Lebar maksimum konten agar kartu tidak melebar berlebihan di layar besar.
  static const double _maxContentWidth = 1100;

  /// Lokasi unik dari mock data, diurutkan abjad (dipakai untuk chip Lokasi).
  static final List<String> _locations =
      mockJobs.map((job) => job.location).toSet().toList()..sort();

  /// Controller teks search bar. Dibuat saat deklarasi dan wajib di-dispose.
  final TextEditingController _searchController = TextEditingController();

  String _searchQuery = '';
  _SalaryFilter? _salaryFilter;
  String? _locationFilter;

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  void _onSearchChanged(String value) {
    setState(() => _searchQuery = value);
  }

  void _clearSearch() {
    _searchController.clear();
    setState(() => _searchQuery = '');
  }

  void _resetFilters() {
    setState(() {
      _salaryFilter = null;
      _locationFilter = null;
    });
  }

  void _resetAll() {
    _searchController.clear();
    setState(() {
      _searchQuery = '';
      _salaryFilter = null;
      _locationFilter = null;
    });
  }

  /// True jika judul, perusahaan, lokasi, atau salah satu keahlian lowongan
  /// memuat [query] (huruf besar/kecil diabaikan). [query] sudah huruf kecil.
  static bool _matchesQuery(Job job, String query) {
    return job.title.toLowerCase().contains(query) ||
        job.company.name.toLowerCase().contains(query) ||
        job.location.toLowerCase().contains(query) ||
        job.requiredSkills.any((skill) => skill.toLowerCase().contains(query));
  }

  /// Tinggi satu [JobCard] (rumus yang sama dengan di home_page.dart).
  /// Grid butuh tinggi yang pasti, jadi dihitung dari susunan JobCard:
  /// padding (2 x md) + jarak antarbaris (xs + sm + xs) + empat baris teks
  /// (24 + 20 + 20 + 16 pada skala 1) dikali skala font perangkat.
  /// Jika tata letak JobCard diubah, sesuaikan angka di sini.
  static double _jobCardHeight(BuildContext context) {
    final textScale = MediaQuery.textScalerOf(context).scale(14) / 14;
    const fixed = AppSpacing.md * 2 + AppSpacing.xs * 2 + AppSpacing.sm;
    return fixed + 80 * textScale + 4; // +4 sebagai cadangan pembulatan
  }

  @override
  Widget build(BuildContext context) {
    final textTheme = Theme.of(context).textTheme;

    final query = _searchQuery.trim().toLowerCase();
    final salary = _salaryFilter;
    final location = _locationFilter;
    final hasActiveFilter = salary != null || location != null;

    // Kata kunci + filter gaji + filter lokasi, semuanya harus cocok.
    final results = mockJobs.where((job) {
      if (query.isNotEmpty && !_matchesQuery(job, query)) return false;
      if (salary != null && !salary.matches(job)) return false;
      if (location != null && job.location != location) return false;
      return true;
    }).toList();

    final cardHeight = _jobCardHeight(context);

    return ResponsiveBuilder(
      builder: (context, screenSize) {
        // LayoutBuilder kedua hanya untuk mengetahui lebar ruang yang tersedia,
        // dipakai memusatkan konten pada layar lebar.
        return LayoutBuilder(
          builder: (context, constraints) {
            const gap = AppSpacing.md;

            final isList = screenSize == ScreenSize.compact;
            final columns = screenSize == ScreenSize.expanded ? 3 : 2;

            final basePadding = switch (screenSize) {
              ScreenSize.compact => AppSpacing.md,
              ScreenSize.medium => AppSpacing.lg,
              ScreenSize.expanded => AppSpacing.xl,
            };

            // Margin kiri-kanan: minimal basePadding, melebar di layar besar
            // sehingga konten tetap di tengah dengan lebar maksimum.
            final inset = math.max(
              basePadding,
              (constraints.maxWidth - _maxContentWidth) / 2,
            );

            return CustomScrollView(
              // Keyboard otomatis tertutup saat daftar digulir (ponsel).
              keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
              slivers: [
                // (1) Search bar.
                SliverPadding(
                  padding: EdgeInsets.fromLTRB(inset, AppSpacing.md, inset, 0),
                  sliver: SliverToBoxAdapter(
                    child: _SearchField(
                      controller: _searchController,
                      hasText: _searchQuery.isNotEmpty,
                      onChanged: _onSearchChanged,
                      onClear: _clearSearch,
                    ),
                  ),
                ),

                // (2) Filter chip. Ponsel: satu baris yang bisa digeser dan
                // menyentuh tepi layar. Layar lebar: chip dibungkus (Wrap).
                SliverToBoxAdapter(
                  child: Padding(
                    padding: const EdgeInsets.only(top: AppSpacing.md),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        _FilterGroup<_SalaryFilter>(
                          title: 'Gaji',
                          options: _SalaryFilter.values,
                          selected: salary,
                          labelOf: (option) => option.label,
                          onChanged: (value) {
                            setState(() => _salaryFilter = value);
                          },
                          inset: inset,
                          wrap: !isList,
                        ),
                        const SizedBox(height: AppSpacing.sm),
                        _FilterGroup<String>(
                          title: 'Lokasi',
                          options: _locations,
                          selected: location,
                          labelOf: (option) => option,
                          onChanged: (value) {
                            setState(() => _locationFilter = value);
                          },
                          inset: inset,
                          wrap: !isList,
                        ),
                      ],
                    ),
                  ),
                ),

                // (3) Jumlah hasil, plus tombol reset saat ada filter aktif.
                SliverPadding(
                  padding: EdgeInsets.fromLTRB(
                    inset,
                    AppSpacing.md,
                    inset,
                    AppSpacing.sm,
                  ),
                  sliver: SliverToBoxAdapter(
                    child: Row(
                      children: [
                        Expanded(
                          child: Semantics(
                            liveRegion: true,
                            child: Text(
                              '${results.length} lowongan ditemukan',
                              style: textTheme.titleSmall,
                            ),
                          ),
                        ),
                        if (hasActiveFilter)
                          TextButton.icon(
                            onPressed: _resetFilters,
                            icon: const Icon(Icons.restart_alt, size: 18),
                            label: const Text('Reset filter'),
                          ),
                      ],
                    ),
                  ),
                ),

                // (4) Daftar hasil: List di ponsel, Grid di layar lebar.
                if (results.isEmpty)
                  SliverPadding(
                    padding: EdgeInsets.symmetric(horizontal: inset),
                    sliver: SliverToBoxAdapter(
                      child: _EmptyResult(onReset: _resetAll),
                    ),
                  )
                else
                  SliverPadding(
                    padding: EdgeInsets.symmetric(horizontal: inset),
                    sliver: isList
                        ? SliverList(
                            delegate: SliverChildBuilderDelegate(
                              (context, index) => Padding(
                                padding: EdgeInsets.only(
                                  bottom:
                                      index == results.length - 1 ? 0 : gap,
                                ),
                                // Navigasi ke detail dikerjakan di Fitur 5.
                                child: JobCard(job: results[index]),
                              ),
                              childCount: results.length,
                            ),
                          )
                        : SliverGrid(
                            gridDelegate:
                                SliverGridDelegateWithFixedCrossAxisCount(
                              crossAxisCount: columns,
                              crossAxisSpacing: gap,
                              mainAxisSpacing: gap,
                              mainAxisExtent: cardHeight,
                            ),
                            delegate: SliverChildBuilderDelegate(
                              (context, index) => JobCard(job: results[index]),
                              childCount: results.length,
                            ),
                          ),
                  ),

                // Ruang kosong di akhir halaman.
                const SliverToBoxAdapter(child: SizedBox(height: AppSpacing.lg)),
              ],
            );
          },
        );
      },
    );
  }
}

/// Search bar Material 3 dengan tombol hapus (X) yang muncul saat ada teks.
class _SearchField extends StatelessWidget {
  const _SearchField({
    required this.controller,
    required this.hasText,
    required this.onChanged,
    required this.onClear,
  });

  final TextEditingController controller;
  final bool hasText;
  final ValueChanged<String> onChanged;
  final VoidCallback onClear;

  @override
  Widget build(BuildContext context) {
    final colorScheme = Theme.of(context).colorScheme;

    return SearchBar(
      controller: controller,
      hintText: 'Cari posisi, perusahaan, atau keahlian',
      leading: const Icon(Icons.search),
      trailing: [
        if (hasText)
          IconButton(
            icon: const Icon(Icons.close),
            tooltip: 'Hapus pencarian',
            onPressed: onClear,
          ),
      ],
      onChanged: onChanged,
      elevation: const WidgetStatePropertyAll(0),
      backgroundColor: WidgetStatePropertyAll(
        colorScheme.surfaceContainerHigh,
      ),
    );
  }
}

/// Satu kategori filter: judul kecil di atas barisan [FilterChip].
/// Pilihan tunggal: menekan chip yang sedang aktif akan membatalkannya
/// ([onChanged] dipanggil dengan null).
///
/// [wrap] true: chip dibungkus ke baris berikutnya (layar lebar).
/// [wrap] false: satu baris yang bisa digeser (ponsel). [inset] adalah margin
/// halaman, dipakai supaya baris yang digeser menyentuh tepi layar.
class _FilterGroup<T> extends StatelessWidget {
  const _FilterGroup({
    required this.title,
    required this.options,
    required this.selected,
    required this.labelOf,
    required this.onChanged,
    required this.inset,
    required this.wrap,
  });

  final String title;
  final List<T> options;
  final T? selected;
  final String Function(T option) labelOf;
  final ValueChanged<T?> onChanged;
  final double inset;
  final bool wrap;

  @override
  Widget build(BuildContext context) {
    final colorScheme = Theme.of(context).colorScheme;
    final textTheme = Theme.of(context).textTheme;

    final chips = <Widget>[
      for (final option in options)
        FilterChip(
          label: Text(labelOf(option)),
          selected: option == selected,
          onSelected: (isSelected) => onChanged(isSelected ? option : null),
        ),
    ];

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: EdgeInsets.symmetric(horizontal: inset),
          child: Text(
            title,
            style: textTheme.labelLarge?.copyWith(
              color: colorScheme.onSurfaceVariant,
            ),
          ),
        ),
        const SizedBox(height: AppSpacing.xs),
        if (wrap)
          Padding(
            padding: EdgeInsets.symmetric(horizontal: inset),
            child: Wrap(
              spacing: AppSpacing.sm,
              runSpacing: AppSpacing.xs,
              children: chips,
            ),
          )
        else
          // Mouse dan trackpad ikut bisa menggeser baris chip
          // (di web, bawaan Flutter hanya mengizinkan sentuhan).
          ScrollConfiguration(
            behavior: ScrollConfiguration.of(context).copyWith(
              dragDevices: {
                PointerDeviceKind.touch,
                PointerDeviceKind.mouse,
                PointerDeviceKind.trackpad,
                PointerDeviceKind.stylus,
              },
            ),
            child: SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              padding: EdgeInsets.symmetric(horizontal: inset),
              child: Row(
                children: [
                  for (var i = 0; i < chips.length; i++) ...[
                    if (i > 0) const SizedBox(width: AppSpacing.sm),
                    chips[i],
                  ],
                ],
              ),
            ),
          ),
      ],
    );
  }
}

/// Tampilan saat tidak ada lowongan yang cocok, dengan tombol reset.
class _EmptyResult extends StatelessWidget {
  const _EmptyResult({required this.onReset});

  final VoidCallback onReset;

  @override
  Widget build(BuildContext context) {
    final colorScheme = Theme.of(context).colorScheme;
    final textTheme = Theme.of(context).textTheme;

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: AppSpacing.xl),
      child: Column(
        children: [
          Icon(Icons.search_off, size: 48, color: colorScheme.onSurfaceVariant),
          const SizedBox(height: AppSpacing.sm),
          Text('Lowongan tidak ditemukan', style: textTheme.titleMedium),
          const SizedBox(height: AppSpacing.xs),
          Text(
            'Coba kata kunci lain atau longgarkan filter gaji dan lokasi.',
            style: textTheme.bodyMedium?.copyWith(
              color: colorScheme.onSurfaceVariant,
            ),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: AppSpacing.md),
          OutlinedButton(
            onPressed: onReset,
            child: const Text('Reset pencarian'),
          ),
        ],
      ),
    );
  }
}